<?php

function addPost():string
{
    $file = file_get_contents(getcwd() . '/blog.json');
    $posts = json_decode($file, true)['posts'];

    //прочитать id Черзе Readline (int)
    //array_key_exists()
    //если пост существует вывести его но не черзе Echo, а через return строки

}

function showAllPosts(): string
{
    $file = @file_get_contents(getcwd() . '/blog.json');

    if (!$file) {
        return handleError("Нет файла с постами blog.json");
    }

    $posts = @json_decode($file, true)['posts'];

    $output = '';
    foreach ($posts as $post) {
        $output .= "{$post['id']}) {$post['title']}" . PHP_EOL;
    }

    return $output;
}